package com.example.productsearch;

public class photoit {
    private  String Photo;

    public void setPhoto(String photo) {
        Photo = photo;
    }

    public String getPhoto() {
        return Photo;
    }

    public photoit(String photo) {
        Photo = photo;
    }


}
